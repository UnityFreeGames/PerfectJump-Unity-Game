﻿public enum GameState_jump {
    MENU,
    PLAYING,
    PAUSED,
    GAMEOVER
}
